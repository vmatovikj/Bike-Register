﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Web.Services;
using System.Net;

public partial class Pocetna : System.Web.UI.Page
{
    public readonly string CONNECTION_STRING = "Data Source=DESKTOP-58DJSD2;Initial Catalog=BikeRegister;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnregister_Click(object sender, EventArgs e)
    {
        Response.Redirect("Najava.aspx");
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
          string cs2 = CONNECTION_STRING;
        Session["connectionstring"] = CONNECTION_STRING;
            using (SqlConnection con = new SqlConnection(cs2))
            {
                string query = "SELECT count (*) from BikeData where serialnumber=@serialnumber";


                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                 cmd.Parameters.Add("@serialnumber", SqlDbType.VarChar);

                    cmd.Parameters["@serialnumber"].Value =txtserial.Text;

                    cmd.ExecuteNonQuery();

             SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                if((int)reader[0]==0)
                {
                     ScriptManager.RegisterStartupScript(Page, Page.GetType(), "key", "<script>alert('This serial number does not exists!')</script>", false);
                }
                else
                {
                    Session["serialnumber"] = txtserial.Text;
                    Response.Redirect("DetalenPregledBezNajava.aspx");
                }
            }  
            con.Close();
                }
                 
            }
}