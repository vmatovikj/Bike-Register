﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Web.Services;
using System.Net;
public partial class RegisteredBikes : System.Web.UI.Page
{
    string query = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlaccentcolor.SelectedIndex = 0;
            ddlbiketype.SelectedIndex = 0;
            ddlframecolor.SelectedIndex = 0;
        }
        else
        {
            int isstolen = 0;
            //query = "";
            if (chkstolen.Checked == true)
            {
                isstolen = 1;
            }

            if (txtmanufacturer.Text != "" || txtmodel.Text != "" || txtyear.Text != "" || ddlframecolor.SelectedIndex != 0 || ddlaccentcolor.SelectedIndex != 0 || ddlbiketype.SelectedIndex != 0 || isstolen==1)
            {
                query = "	exec sp_ListAllBikesForAllUsersFiltered  '" + txtmanufacturer.Text + "', '" + txtmodel.Text + "', '" + isstolen.ToString() + "', '" + txtyear.Text + "', '" + ddlframecolor.SelectedIndex.ToString() + "', '" +
               ddlaccentcolor.SelectedIndex.ToString() + "', '" + ddlbiketype.SelectedIndex.ToString() + "'";
            }
            if (query != "")
            {
                string cs2 = (string)Session["connectionstring"];
                using (SqlConnection con = new SqlConnection(cs2))
                {
                    // string query = "SELECT serialnumber, ID from BikeData where Username='" + (string)Session["username"] + "' order by ID";


                    // query = "	exec sp_ListAllBikesForAllUsersFiltered  '" + txtmanufacturer.Text + "', '" + txtmodel.Text + "', '" + isstolen.ToString() + "', '" + txtyear.Text + "', '" + ddlframecolor.SelectedIndex.ToString() + "', '" +
                    // ddlaccentcolor.SelectedIndex.ToString() + "', '" + ddlbiketype.SelectedIndex.ToString() + "'";
                    SqlCommand cmd = new SqlCommand(query, con);
                    //serialnumber                             ID          Username             manufacturer                                       model                                              modelyear   owneremail                                         ddlframecolor ddlAccentColor ddlBikeType Stollen serialnumber                             ID          FileName    

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    string strDivs = string.Empty;
                    while (reader.Read())
                    {



                        divOnPage.Controls.Add(new LiteralControl("<div class='row'><div class='col-xs-12 col-sm-12 col-md-12 col-lg-12'><div class='panel panel-primary'><div class='panel-body'><div class='row'><div class='col-xs-4 col-sm-4 col-md-4 col-lg-4 text-left marginPost'><h3 class='paragrafPost'>" + (string)reader[0] + "</h3></div><div class='col-xs-8 col-sm-8 col-md-8 col-lg-8 text-right'>"));


                        Image slika = new Image();
                        slika.CssClass = "img-responsive img-thumbnail";
                        slika.Height = 200;
                        slika.Width = 400;



                        if (reader["FileName"] != DBNull.Value)
                        {
                            slika.ImageUrl = "~/Uploads/" + Convert.ToString(reader[13]);
                        }
                        else
                        {
                            slika.ImageUrl = "img/1506237.gif";
                        }






                        divOnPage.Controls.Add(slika);

                        divOnPage.Controls.Add(new LiteralControl("</div></div></div><div class='panel-footer'><div class='row'><div class='col-xs-12 col-sm-12 col-md-12 col-lg-12 text-right'>"));

                        Button btndetail = new Button();
                        btndetail.ID = Convert.ToString(reader[1]);
                        btndetail.Text = "Detail View";
                        btndetail.CssClass = "btn btn-primary dropdown-toggle";
                        btndetail.Click += new EventHandler(opendetail);

                        divOnPage.Controls.Add(btndetail);
                        divOnPage.Controls.Add(new LiteralControl("</div></div></div></div></div></div>"));

                    }
                    con.Close();


                }
            }
        }


    }

  

      protected void btnmybikes_Click(object sender, EventArgs e)
    {
        Response.Redirect("Registracija.aspx");
    }

    protected void btnallbikes_Click(object sender, EventArgs e)
    {
        Response.Redirect("MyBikes.aspx");
    }

    protected void btnsignout_Click(object sender, EventArgs e)
    {
        Response.Redirect("Pocetna.aspx");
    }

    protected void btnsearchserial_Click(object sender, EventArgs e)
    {
           string cs2 = (string)Session["connectionstring"];
        Session["connectionstring"] = (string)Session["connectionstring"];
            using (SqlConnection con = new SqlConnection(cs2))
            {
                string query = "SELECT count (*) from BikeData where serialnumber=@serialnumber";


                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                 cmd.Parameters.Add("@serialnumber", SqlDbType.VarChar);

                    cmd.Parameters["@serialnumber"].Value =txtserial.Text;

                    cmd.ExecuteNonQuery();

             SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                if((int)reader[0]==0)
                {
                     ScriptManager.RegisterStartupScript(Page, Page.GetType(), "key", "<script>alert('This serial number does not exists!')</script>", false);
                }
                else
                {
                    Session["serialnumber"] = txtserial.Text;
                    Response.Redirect("DetalenPregledNaSite.aspx");
                }
            }  
            con.Close();
                }
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
            
            // string query = "SELECT serialnumber, ID from BikeData where Username='" + (string)Session["username"] + "' order by ID";
            /*
            int isstolen = 0;
            if (chkstolen.Checked == true)
            {
                isstolen = 1;
            }

            query = "	exec sp_ListAllBikesForAllUsersFiltered  '" + txtmanufacturer.Text + "', '" + txtmodel.Text + "', '" + isstolen.ToString() + "', '" + txtyear.Text + "', '" + ddlframecolor.SelectedIndex.ToString() + "', '" +
                ddlaccentcolor.SelectedIndex.ToString() + "', '" + ddlbiketype.SelectedIndex.ToString() + "'";

         Response.Redirect("RegisteredBikes.aspx");
*/
        
    }


    protected void opendetail(object sender, EventArgs e)
    {
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "key", "<script>alert('This serial number does not exists!')</script>", false);
        Button button = (Button)sender;
        string buttonid = button.ID;

          string cs2 = (string)Session["connectionstring"];
        using (SqlConnection con = new SqlConnection(cs2))
        {
            string query = "SELECT serialnumber from BikeData where ID='" + buttonid + "'";

            SqlCommand cmd = new SqlCommand(query, con);


            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Session["serialnumber"] = Convert.ToString(reader[0]);
            }
            con.Close();
        }

        Response.Redirect("DetalenPregledNaSite.aspx");
    }
}