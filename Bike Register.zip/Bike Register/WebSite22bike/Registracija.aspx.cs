﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Web.Services;
using System.Net;

public partial class Registracija : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("MyBikes.aspx");
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (fileupload.HasFile == false)
    {
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "key", "<script>alert('No File Uploaded.')</script>", false);
    }

    else    
    {
             string cs2 = (string)Session["connectionstring"];
            using (SqlConnection con = new SqlConnection(cs2))
            {
                string query = "INSERT INTO BikePhotos (serialnumber,FileName) values(@par1,@par2)";


                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                 cmd.Parameters.Add("@par1", SqlDbType.VarChar);
                 cmd.Parameters.Add("@par2", SqlDbType.VarChar);
                foreach (HttpPostedFile file in fileupload.PostedFiles)
                {
                    string fileExtension = System.IO.Path.GetExtension(file.FileName);
                    string FileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(file.FileName);
                    string ime = FileNameWithoutExtension + System.DateTime.Now.ToString("ddMMyyhhmmss") + fileExtension;
                    //string filename = Path.GetFileName(file.FileName);
                    file.SaveAs(Server.MapPath("~/Uploads/" + ime));

                    //[serialnumber]  [varchar](40) NOT NULL,

                    // [FileName] [varchar](300) NOT NULL,
                    cmd.Parameters["@par1"].Value =serialnumber.Text;

                    cmd.Parameters["@par2"].Value = ime;
 
                    cmd.ExecuteNonQuery();

                    Image slika = new Image();
                    slika.ImageUrl = "~/Uploads/" + ime;
                    slika.Width = 400;
                    slika.Height = 200;
                    divonpage.Controls.Add(slika);

                }
                 con.Close();
            }  
    }

    }

    protected void btnregister_Click(object sender, EventArgs e)
    {
        /*serialnumber
		manufacturer
		model
		modelyear
		owner
		desc
		
		ddlframe
		ddlaccent
		ddlbike
        
        Session["serialnumber"] = serialnumber.Text;
         Session["manufacturer"] = manufacturer.Text;
         Session["model"] = model.Text;
         Session["modelyear"] = modelyear.Text;
         Session["owneremail"] = owneremail.Text;
         Session["description"] = description.Text;
        Session["ddlframecolor"] = ddlframecolor.SelectedIndex;
        Session["ddlAccentColor"] = ddlAccentColor.SelectedIndex;
        Session["ddlBikeType"] = ddlBikeType.SelectedIndex;
*/

        /*
         * [sp_AddNewBike] (
	@serialnumber varchar(40),
  @Username [varchar](20),
  @manufacturer [varchar](50),
  @model [varchar](50),
  @modelyear [integer],
  @owneremail [varchar](50),
  @ddlframecolor [integer],
  @ddlAccentColor [integer],
  @ddlBikeType [integer],
  @Stollen SmallInt,
  @RetID [integer] out */

        String connectionstring = (string)Session["connectionstring"];
        int id = 0;
        string xSerial = "";

        using (SqlConnection con = new SqlConnection(connectionstring))
        {
            SqlCommand cmd = new SqlCommand("sp_AddNewBike", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter paramSerial = new SqlParameter()
            {
                ParameterName = @"serialnumber",
                Value = serialnumber.Text
            };
            cmd.Parameters.Add(paramSerial);

            SqlParameter paramMan = new SqlParameter()
            {
                ParameterName = @"manufacturer",
                Value = manufacturer.Text
            };
            cmd.Parameters.Add(paramMan);

            SqlParameter param1 = new SqlParameter()
            {
                ParameterName = @"model",
                Value = model.Text
            };
            cmd.Parameters.Add(param1);

             SqlParameter param2 = new SqlParameter()
            {
                ParameterName = @"modelyear",
                Value = modelyear.Text
            };
            cmd.Parameters.Add(param2);

             SqlParameter param3 = new SqlParameter()
            {
                ParameterName = @"owneremail",
                Value = owneremail.Text
            };
            cmd.Parameters.Add(param3);

             SqlParameter param4 = new SqlParameter()
            {
                ParameterName = @"ddlframecolor",
                Value = ddlframecolor.SelectedIndex
            };
            cmd.Parameters.Add(param4);

             SqlParameter param5 = new SqlParameter()
            {
                ParameterName = @"ddlAccentColor",
                Value = ddlAccentColor.SelectedIndex
            };
            cmd.Parameters.Add(param5);

             SqlParameter param6 = new SqlParameter()
            {
                ParameterName = @"ddlBikeType",
                Value = ddlBikeType.SelectedIndex
            };
            cmd.Parameters.Add(param6);

             SqlParameter param7 = new SqlParameter()
            {
                ParameterName = @"Username",
                Value = (string)Session["username"]
            };
            cmd.Parameters.Add(param7);
           
            SqlParameter returnParameter = cmd.Parameters.Add("@RetID", SqlDbType.Int);
            returnParameter.Direction = ParameterDirection.Output;

            SqlParameter param8 = new SqlParameter()
            {
                ParameterName = @"Description",
                Value = description.Text
            };
            cmd.Parameters.Add(param8);

            con.Open();
            cmd.ExecuteNonQuery();
             id = (int) returnParameter.Value;
            con.Close();

        }

        if(id==-1)
        {
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "key", "<script>alert('This serial number already exists!')</script>", false);
            serialnumber.Focus();
        }

        else
        {
            Session["serialnumber"] = serialnumber.Text;
            Response.Redirect("Detalen_Pregled.aspx");
        }
        
    }



  
}