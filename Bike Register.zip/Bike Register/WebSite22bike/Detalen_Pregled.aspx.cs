﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Web.Services;
using System.Net;

public partial class Detalenregled : System.Web.UI.Page
{
    bool prvpat=true;
    protected void Page_Load(object sender, EventArgs e)
    {
        String connectionstring = (string)Session["connectionstring"];
        if (!Page.IsPostBack)
        {
            /*
            Session["serialnumber"] = serialnumber.Text;
         Session["manufacturer"] = manufacturer.Text;
         Session["model"] = model.Text;
         Session["modelyear"] = modelyear.Text;
         Session["owneremail"] = owneremail.Text;
         Session["description"] = description.Text;
        Session["ddlframecolor"] = ddlframecolor.SelectedItem.Text;
        Session["ddlAccentColor"] = ddlAccentColor.SelectedItem.Text;
        Session["ddlBikeType"] = ddlBikeType.SelectedItem.Text;
        */
            int stollen=0;
            serialnumber.Text = (string)Session["serialnumber"];

            /*
            manufacturer.Text = (string)Session["manufacturer"];
            model.Text = (string)Session["model"];
            modelyear.Text = (string)Session["modelyear"];
            owneremail.Text = (string)Session["owneremail"];
            description.Text = (string)Session["description"];
            
           ddlframecolor.Text = (string)Session["ddlframecolor"];
            ddlAccentColor.Text = (string)Session["ddlAccentColor"];
            ddlBikeType.Text = (string)Session["ddlBikeType"];
*/

            /*
             *  serialnumber,Username,manufacturer,model,modelyear,owneremail,ddlframecolor,ddlAccentColor,
  ddlBikeType,Stollen*/

            //String connectionstring = (string)Session["connectionstring"];
            int id = 0;


            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("sp_GetBikeBySerial", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter paramSerial = new SqlParameter()
                {
                    ParameterName = @"serialnumber",
                    Value = (string)Session["serialnumber"]
                };
                cmd.Parameters.Add(paramSerial);


                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    manufacturer.Text = (string)reader[2];
                    model.Text = (string)reader[3];
                    modelyear.Text = Convert.ToString(reader[4]);
                    owneremail.Text = (string)reader[5];


                    ddlframecolor.SelectedIndex = (int)reader[6];
                    ddlAccentColor.SelectedIndex = (int)reader[7];
                    ddlBikeType.SelectedIndex = (int)reader[8];
                    stollen = Convert.ToInt16(reader[9]);
                    if((int)reader[10]==1)
                    {
                        sale.Checked = true;
                        ddlbuyers.Enabled = true;
                        btnallow.Enabled = true;
                    }
                    else
                    {
                        sale.Checked = false;
                         ddlbuyers.Enabled = false;
                         btnallow.Enabled = false;
                    }
                }

                con.Close();

            }


            using (SqlConnection con = new SqlConnection(connectionstring))
            {

                string query = "select fromusername from sale where serialnumber='" + (string)Session["serialnumber"] + "' and allowed=0";
                  SqlCommand cmd1 = new SqlCommand(query, con);
                                  
                    con.Open();
                    SqlDataReader reader1 = cmd1.ExecuteReader();
                while (reader1.Read())
                {
                    ddlbuyers.Items.Add((string)reader1[0]);
                }
                con.Close();
            }


            ReadModifiedDesc();

            if (prvpat == true)
            {
                serialnumber.ReadOnly = true;
                manufacturer.ReadOnly = true;
                model.ReadOnly = true;
                modelyear.ReadOnly = true;
                owneremail.ReadOnly = true;
                description.ReadOnly = true;
                insertdesc.ReadOnly = true;

                btnsavebike.Visible = false;
                btncancel.Visible = false;
                stolen.Visible = false;


                btnsave.Enabled = false;
                fileupload.Enabled = false;

                ddlframecolor.Enabled = false;
                ddlAccentColor.Enabled = false;
                ddlBikeType.Enabled = false;
                ddlframecolor.CssClass = "class";
                ddlAccentColor.CssClass = "class";
                ddlBikeType.CssClass = "class";
                 if(stollen==1)
                    {
                       body.Style.Add("background-color", "Crimson");
                    stolen.Checked = true;
                    }
                    else
                    {
                         body.Style.Add("background-color", "cadetblue");
                        stolen.Checked = false;
                    }

            }

        }

        /*
        if(ddlbuyers.Items.Count!=0)
        {
            ddlbuyers.Enabled = true;
            btnallow.Enabled = true;
        }
        else
        {
            
            ddlbuyers.Enabled = false;
            btnallow.Enabled = false;
        }
        */

        string cs2 = (string)Session["connectionstring"];
        using (SqlConnection con = new SqlConnection(cs2))
        {
            string query = "SELECT FileName from BikePhotos where serialnumber=@serialnumber order by ID";


            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.Add("@serialnumber", SqlDbType.VarChar);
            cmd.Parameters["@serialnumber"].Value =serialnumber.Text;

            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
             
            while (reader.Read())
            {
                Image slika = new Image();
                slika.ImageUrl = "~/Uploads/" + reader[0];
                slika.Width = 400;
                slika.Height = 200;
                divonpage.Controls.Add(slika);

            }
            con.Close();
           
        }
         
    }
    protected void ReadModifiedDesc()
    {

        String connectionstring = (string)Session["connectionstring"];
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("sp_GetBikeDesc", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter paramSerial = new SqlParameter()
                {
                    ParameterName = @"serialnumber",
                    Value = (string)Session["serialnumber"]
                };
                cmd.Parameters.Add(paramSerial);

                 bool Isfirstline = true;

                description.Text = "";
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (Isfirstline == true) { 
                    description.Text = Convert.ToString(reader[2]) + " - " + (string)reader[3];
                    Isfirstline = false;
                        }
                    else
                    {
                         description.Text = description.Text + "\n" + Convert.ToString(reader[2]) + " - " + (string)reader[3];
                        
                    }
                       
                }

                con.Close();

            }
    }

    protected void btnmodify_Click(object sender, EventArgs e)
    {

            //serialnumber.ReadOnly = false;
            manufacturer.ReadOnly = false;
            model.ReadOnly = false;
            modelyear.ReadOnly = false;
            owneremail.ReadOnly = false;
            //description.ReadOnly = false;
            insertdesc.ReadOnly = false;
            
        
            btnsave.Enabled = true;
            fileupload.Enabled = true;

            ddlframecolor.Enabled=true;
            ddlAccentColor.Enabled=true;
            ddlBikeType.Enabled=true;
            ddlframecolor.CssClass = "btn btn-primary dropdown-toggle";
            ddlAccentColor.CssClass = "btn btn-primary dropdown-toggle";
            ddlBikeType.CssClass = "btn btn-primary dropdown-toggle";
            
        
       // Button1.Enabled = true;
            btnsavebike.Enabled = true;
            btncancel.Enabled = true;
            stolen.Enabled = true;
            btnmodify.Enabled = false;

                btnsavebike.Visible = true;
                btncancel.Visible = true;
                stolen.Visible = true;

        
    }

    protected void btnsavebike_Click(object sender, EventArgs e)
    {
         /*
         * [serialnumber]  [varchar](40) NOT NULL,
	[ID] integer identity (1,1),
	[Username] [varchar](20) NOT NULL,
	[manufacturer]  [varchar](50) NULL,
	[model]  [varchar](50) NULL,
	[modelyear]    [integer]  NULL,
	[owneremail]  [varchar](50) NULL,
	--[description]   [varchar](50) NULL,
	[ddlframecolor]  [integer]  NULL,
	[ddlAccentColor]  [integer]  NULL,
	[ddlBikeType]  [integer]  NULL,
  [Stollen] SmallInt default (0), */

        int ukradeno = 0;
        if (stolen.Checked)
            ukradeno = 1;

        String connectionstring = (string)Session["connectionstring"];
        using(SqlConnection connection = new SqlConnection(connectionstring))
        {
            connection.Open();
            string query = "UPDATE BikeData set "+ 
                "manufacturer='"+manufacturer.Text+"', "+
                "model='"+model.Text+"', "+
                "modelyear="+modelyear.Text+", "+
                "owneremail='"+owneremail.Text+"', "+
                "ddlframecolor="+ddlframecolor.SelectedIndex.ToString()+", "+
                "ddlAccentColor='"+ddlAccentColor.SelectedIndex.ToString()+"', "+
                "ddlBikeType='"+ddlBikeType.SelectedIndex.ToString()+"', "+
                "Stollen="+ukradeno.ToString()+" "+
                "  WHERE serialnumber='"+ (string)Session["serialnumber"]+"'";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.ExecuteNonQuery();
             
            }

            //[DescLine] [varchar](1000)  NULL,
            //	[serialnumber]  [varchar](40) NOT NULL,
            if (insertdesc.Text != "")
            {
                query = "INSERT into BikeDescriptions(serialnumber,DescLine) VALUES('" + (string)Session["serialnumber"] + "' , '" + insertdesc.Text + "')";
                 using (SqlCommand command = new SqlCommand(query, connection))
                {
                command.ExecuteNonQuery();
             
                }
            }

            connection.Close();
        }

            serialnumber.ReadOnly = true;
            manufacturer.ReadOnly = true;
            model.ReadOnly = true;
            modelyear.ReadOnly = true;
            owneremail.ReadOnly = true;
           // description.ReadOnly = true;
            insertdesc.ReadOnly = true;

            
            btnsave.Enabled = false;
            fileupload.Enabled = false;

            ddlframecolor.Enabled=false;
            ddlAccentColor.Enabled=false;
            ddlBikeType.Enabled=false;
            ddlframecolor.CssClass = "class";
            ddlAccentColor.CssClass = "class";
            ddlBikeType.CssClass = "class";

        
        //Button1.Enabled = false;
            btnsavebike.Enabled = false;
            btncancel.Enabled = false;
            stolen.Enabled = false;
            btnmodify.Enabled = true;

                btnsavebike.Visible = false;
                btncancel.Visible = false;
                stolen.Visible = false;


        ReadModifiedDesc();
        insertdesc.Text = "";
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        /*
         serialnumber.Text = (string)Session["serialnumber"];
            manufacturer.Text = (string)Session["manufacturer"];
            model.Text = (string)Session["model"];
            modelyear.Text = (string)Session["modelyear"];
            owneremail.Text = (string)Session["owneremail"];
            description.Text = (string)Session["description"];
            
           ddlframecolor.Text = (string)Session["ddlframecolor"];
            ddlAccentColor.Text = (string)Session["ddlAccentColor"];
            ddlBikeType.Text = (string)Session["ddlBikeType"];

            string boja = (string)Session["bgcolor"];
            if(boja=="background-color:cadetblue")
             body.Style.Add("background-color", "cadetblue");
            else
             body.Style.Add("background-color", "Crimson");
             bool ischecked = (bool)Session["checked"];
        if (ischecked == true)
            stolen.Checked = true;
        else
            stolen.Checked = false; 

            */
            

            serialnumber.ReadOnly = true;
            manufacturer.ReadOnly = true;
            model.ReadOnly = true;
            modelyear.ReadOnly = true;
            owneremail.ReadOnly = true;
            //description.ReadOnly = true;
            insertdesc.ReadOnly = true;

            ddlframecolor.Enabled=false;
            ddlAccentColor.Enabled=false;
            ddlBikeType.Enabled=false;
            ddlframecolor.CssClass = "class";
            ddlAccentColor.CssClass = "class";
            ddlBikeType.CssClass = "class";
            
        
            btnsave.Enabled = false;
            fileupload.Enabled = false;

       // Button1.Enabled = false;
            btnsavebike.Enabled = false;
            btncancel.Enabled = false;
            stolen.Enabled = false;
            btnmodify.Enabled = true;

                btnsavebike.Visible = false;
                btncancel.Visible = false;
                stolen.Visible = false;


        Response.Redirect("Detalen_Pregled.aspx");
        
    }

    protected void sale_CheckedChanged(object sender, EventArgs e)
    {
        int i = 0;
        if(sale.Checked==true)
        {
            i = 1;
             ddlbuyers.Enabled = true;
             btnallow.Enabled = true;
        }
        else
        {
            ddlbuyers.Enabled = false;
            btnallow.Enabled = false;
        }
     
          String connectionstring = (string)Session["connectionstring"];
        using(SqlConnection connection = new SqlConnection(connectionstring))
        {
            connection.Open();
            string query = "UPDATE BikeData set "+ 
                "ForSale="+i.ToString()+" WHERE serialnumber='"+ (string)Session["serialnumber"]+"'"; 
              
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.ExecuteNonQuery();
             
            }

            connection.Close();
        }
    }

    protected void stolen_CheckedChanged(object sender, EventArgs e)
    {
        if(stolen.Checked==true)
        {
           body.Style.Add("background-color", "Crimson");
        }
        else
        {
             body.Style.Add("background-color", "cadetblue");
        }
    }

    protected void btnhome_Click(object sender, EventArgs e)
    {
        Response.Redirect("MyBikes.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         ScriptManager.RegisterStartupScript(Page, Page.GetType(), "key", "<script>alert('ALERT!')</script>", false);
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
         if (fileupload.HasFile == false)
    {
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "key", "<script>alert('No File Uploaded.')</script>", false);
    }

    else    
    {
             string cs2 = (string)Session["connectionstring"];
            using (SqlConnection con = new SqlConnection(cs2))
            {
                string query = "INSERT INTO BikePhotos (serialnumber,FileName) values(@par1,@par2)";


                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                 cmd.Parameters.Add("@par1", SqlDbType.VarChar);
                 cmd.Parameters.Add("@par2", SqlDbType.VarChar);
                foreach (HttpPostedFile file in fileupload.PostedFiles)
                {
                    string fileExtension = System.IO.Path.GetExtension(file.FileName);
                    string FileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(file.FileName);
                    string ime = FileNameWithoutExtension + System.DateTime.Now.ToString("ddMMyyhhmmss") + fileExtension;
                    //string filename = Path.GetFileName(file.FileName);
                    file.SaveAs(Server.MapPath("~/Uploads/" + ime));

                    //[serialnumber]  [varchar](40) NOT NULL,

                    // [FileName] [varchar](300) NOT NULL,
                    cmd.Parameters["@par1"].Value =serialnumber.Text;

                    cmd.Parameters["@par2"].Value = ime;
 
                    cmd.ExecuteNonQuery();

                    //Image slika = new Image();
                    //slika.ImageUrl = "~/Uploads/" + ime;
                   // slika.Width = 400;
                    //slika.Height = 200;
                   // divonpage.Controls.Add(slika);

                }
                 con.Close();
            }
            prvpat = false;  
            Response.Redirect("Detalen_Pregled.aspx");
    }

         
    }


    protected void btnallow_Click(object sender, EventArgs e)
    {
            String connectionstring = (string)Session["connectionstring"];

        using (SqlConnection con = new SqlConnection(connectionstring))
        {

            string query = "update sale set allowed=case when fromusername='" + ddlbuyers.SelectedItem.Text + "' then 1 else 2 end where serialnumber='" + serialnumber.Text + "'";
            SqlCommand cmd1 = new SqlCommand(query, con);

            con.Open();
            cmd1.ExecuteNonQuery();
            con.Close();
        }
        using (SqlConnection con = new SqlConnection(connectionstring))
        {
            string query1 = "update bikedata set forsale=0, username='" + ddlbuyers.SelectedItem.Text + "' where username='" + (string)Session["username"] + "' and serialnumber='"+ serialnumber.Text + "'";
                      SqlCommand cmd = new SqlCommand(query1, con);
                                  
                    con.Open();
                      cmd.ExecuteNonQuery();
                    con.Close();

        }


        ddlbuyers.Items.Clear();
        ddlbuyers.Enabled = false;
        btnallow.Enabled = false;
        sale.Checked = false;

        Response.Redirect("MyBikes.aspx");

    }
}