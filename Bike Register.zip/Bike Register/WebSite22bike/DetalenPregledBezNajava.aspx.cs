﻿
using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Web.Services;
using System.Net;

public partial class DetalenPregledBezNajava : System.Web.UI.Page
{
   // bool prvpat=true;
    protected void Page_Load(object sender, EventArgs e)
    {
        String connectionstring = (string)Session["connectionstring"];
        if (!Page.IsPostBack)
        {
            /*
            Session["serialnumber"] = serialnumber.Text;
         Session["manufacturer"] = manufacturer.Text;
         Session["model"] = model.Text;
         Session["modelyear"] = modelyear.Text;
         Session["owneremail"] = owneremail.Text;
         Session["description"] = description.Text;
        Session["ddlframecolor"] = ddlframecolor.SelectedItem.Text;
        Session["ddlAccentColor"] = ddlAccentColor.SelectedItem.Text;
        Session["ddlBikeType"] = ddlBikeType.SelectedItem.Text;
        */

            lblserial.Text = (string)Session["serialnumber"];
            int stollen=0;

            /*
            manufacturer.Text = (string)Session["manufacturer"];
            model.Text = (string)Session["model"];
            modelyear.Text = (string)Session["modelyear"];
            owneremail.Text = (string)Session["owneremail"];
            description.Text = (string)Session["description"];
            
           ddlframecolor.Text = (string)Session["ddlframecolor"];
            ddlAccentColor.Text = (string)Session["ddlAccentColor"];
            ddlBikeType.Text = (string)Session["ddlBikeType"];
*/

            /*
             *  serialnumber,Username,manufacturer,model,modelyear,owneremail,ddlframecolor,ddlAccentColor,
  ddlBikeType,Stollen*/

            //String connectionstring = (string)Session["connectionstring"];
            int id = 0;


            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("sp_GetBikeBySerial", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter paramSerial = new SqlParameter()
                {
                    ParameterName = @"serialnumber",
                    Value = (string)Session["serialnumber"]
                };
                cmd.Parameters.Add(paramSerial);


                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                      
              

                    lblmanufacturer.Text = (string)reader[2];
                    lblmodel.Text = (string)reader[3];
                    lblyear.Text = Convert.ToString(reader[4]);
                    lblemail.Text = (string)reader[5];

                    string[] boi = { "", "Beige", "Black", "Blue", "Bronze", "Brown", "Copper", "Gold", "Green", "Orange", "Pink", "Purple", "Red", "White", "Silver", "Yellow" };
                    string[] bike =  { "", "BMX", "Cargo", "Commuter", "Cruiser", "Custom", "Cyclocross", "Electric", "Elliptical", "Fat", "Folding", "Freestyle", "Hybrid",
                        "Mountain", "Mixte", "Recumbent", "Road", "Step Through", "Tandem", "Touring", "Track", "Trial",
                        "Triathlon", "Tricycle", "Unicycle", "Youth"};
                    //<asp:ListItem>---Accent Color---</asp:ListItem>
                    //<asp:ListItem>---Bike Type---</asp:ListItem>


                    lblframe.Text = boi[(int)reader[6]];
                    lblaccent.Text = boi[(int)reader[7]];
                    lblbiketype.Text = bike[(int)reader[8]];
                    stollen = Convert.ToInt16(reader[9]);
              

                }

                con.Close();
            }
                
          

            if(stollen==1)
                    {
                       body.Style.Add("background-color", "Crimson");
                    stolen.Checked = true;
                    }
                    else
                    {
                         body.Style.Add("background-color", "cadetblue");
                        stolen.Checked = false;
                    }
             description.ReadOnly = true;
            //ReadModifiedDesc();

            /*
                serialnumber.ReadOnly = true;
                manufacturer.ReadOnly = true;
                model.ReadOnly = true;
                modelyear.ReadOnly = true;
                owneremail.ReadOnly = true;
                description.ReadOnly = true;
                insertdesc.ReadOnly = true;

                btnsave.Enabled = false;
                fileupload.Enabled = false;

                ddlframecolor.Enabled = false;
                ddlAccentColor.Enabled = false;
                ddlBikeType.Enabled = false;
                ddlframecolor.CssClass = "class";
                ddlAccentColor.CssClass = "class";
                ddlBikeType.CssClass = "class";
           */ 

        }

        string cs2 = (string)Session["connectionstring"];
        using (SqlConnection con = new SqlConnection(cs2))
        {
            string query = "SELECT FileName from BikePhotos where serialnumber=@serialnumber order by ID";


            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.Add("@serialnumber", SqlDbType.VarChar);
            cmd.Parameters["@serialnumber"].Value =lblserial.Text;

            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
             
            while (reader.Read())
            {
                Image slika = new Image();
                slika.ImageUrl = "~/Uploads/" + reader[0];
                slika.Width = 400;
                slika.Height = 200;
                divonpage.Controls.Add(slika);

            }
            con.Close();
           
        }

        
      
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("sp_GetBikeDesc", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter paramSerial = new SqlParameter()
                {
                    ParameterName = @"serialnumber",
                    Value = (string)Session["serialnumber"]
                };
                cmd.Parameters.Add(paramSerial);

                 bool Isfirstline = true;

                description.Text = "";
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (Isfirstline == true) { 
                    description.Text = Convert.ToString(reader[2]) + " - " + (string)reader[3];
                    Isfirstline = false;
                        }
                    else
                    {
                         description.Text = description.Text + "\n" + Convert.ToString(reader[2]) + " - " + (string)reader[3];
                        
                    }
                       
                }

                con.Close();

            }
         
    }


    protected void btnhome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Pocetna.aspx");

    }


   

   

         
    

}